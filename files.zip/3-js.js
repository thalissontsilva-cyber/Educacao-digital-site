const KEY = "studyhub-v2";
let S = { subjects: [], tasks: [], videos: [], tab: "painel", filter: "all", q: "", sessions: 0, theme: "" };
try { Object.assign(S, JSON.parse(localStorage.getItem(KEY))); } catch (e) {}
if (!S.subjects.length) S.subjects = [
  { id: "s1", name: "Matemática", color: "#6366f1" },
  { id: "s2", name: "Português", color: "#10b981" }];
if (!S.theme) S.theme = matchMedia("(prefers-color-scheme:dark)").matches ? "dark" : "light";

const $ = s => document.querySelector(s);
const uid = () => Math.random().toString(36).slice(2, 9);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
const sub = id => S.subjects.find(s => s.id === id) || { name: "—", color: "#999" };
const today = () => new Date().toISOString().slice(0, 10);
const fmt = d => d ? d.split("-").reverse().join("/") : "sem data";
const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
const ytId = u => { const m = (u || "").match(/(?:v=|youtu\.be\/|embed\/)([\w-]{11})/); return m ? m[1] : null; };
const cmp = (a, b) => (a.date || "9").localeCompare(b.date || "9") || a.prio - b.prio;
const opts = () => S.subjects.map(s => [s.id, s.name]);

/* ---------- Modal genérico (usado para criar/editar tudo) ---------- */
function form(title, fields, vals, ok) {
  const d = $("#dlg");
  d.innerHTML = `<form method="dialog"><h3>${title}</h3>${fields.map(f => `<label>${f.l}${f.o
    ? `<select name="${f.k}">${f.o.map(o => `<option value="${o[0]}" ${vals[f.k] == o[0] ? "selected" : ""}>${esc(o[1])}</option>`).join("")}</select>`
    : `<input name="${f.k}" type="${f.t || "text"}" value="${esc(vals[f.k] || "")}" ${f.r ? "required" : ""}>`}</label>`).join("")}
    <div class="row end"><button type="button" class="ghost" onclick="dlg.close()">Cancelar</button><button class="btn">Salvar</button></div></form>`;
  d.querySelector("form").onsubmit = e => { ok(Object.fromEntries(new FormData(e.target))); save(); render(); };
  d.showModal();
}
const needSubj = () => !S.subjects.length && (alert("Crie uma matéria primeiro."), true);

/* ---------- Ações ---------- */
function editSubj(id) {
  const s = S.subjects.find(x => x.id === id) || { color: "#6366f1" };
  form(id ? "Editar matéria" : "Nova matéria", [{ k: "name", l: "Nome", r: 1 }, { k: "color", l: "Cor", t: "color" }], s,
    o => id ? Object.assign(s, o) : S.subjects.push({ id: uid(), ...o }));
}
function delSubj(id) {
  if (!confirm("Remover a matéria, suas tarefas e videoaulas?")) return;
  S.subjects = S.subjects.filter(s => s.id !== id);
  S.tasks = S.tasks.filter(t => t.subject !== id);
  S.videos = S.videos.filter(v => v.subject !== id);
  save(); render();
}
function editTask(id) {
  if (needSubj()) return;
  const t = S.tasks.find(x => x.id === id) || { prio: "2" };
  form(id ? "Editar tarefa" : "Nova tarefa", [
    { k: "name", l: "Tarefa", r: 1 }, { k: "subject", l: "Matéria", o: opts() },
    { k: "date", l: "Data de entrega", t: "date" }, { k: "prio", l: "Prioridade", o: [["1", "Alta"], ["2", "Média"], ["3", "Baixa"]] }],
    t, o => id ? Object.assign(t, o) : S.tasks.push({ id: uid(), done: false, ...o }));
}
const togTask = id => { const t = S.tasks.find(x => x.id === id); t.done = !t.done; save(); render(); };
const delTask = id => { S.tasks = S.tasks.filter(t => t.id !== id); save(); render(); };
function editVid(id) {
  if (needSubj()) return;
  const v = S.videos.find(x => x.id === id) || {};
  form(id ? "Editar videoaula" : "Nova videoaula", [
    { k: "name", l: "Título", r: 1 }, { k: "url", l: "Link do YouTube", r: 1 }, { k: "subject", l: "Matéria", o: opts() }],
    v, o => {
      if (!ytId(o.url)) return alert("Link do YouTube inválido.");
      id ? Object.assign(v, o) : S.videos.push({ id: uid(), seen: false, ...o });
    });
}
const togVid = id => { const v = S.videos.find(x => x.id === id); v.seen = !v.seen; save(); render(); };
const delVid = id => { S.videos = S.videos.filter(v => v.id !== id); save(); render(); };
function setTab(t) { S.tab = t; save(); render(); }
function set(k, v) { S[k] = v; render(); }

/* ---------- Renderização ---------- */
function taskRow(t) {
  const late = !t.done && t.date && t.date < today(), s = sub(t.subject);
  return `<div class="task ${t.done ? "done" : ""}">
    <input type="checkbox" ${t.done ? "checked" : ""} onchange="togTask('${t.id}')">
    <div class="grow"><div class="nm">${esc(t.name)}</div>
    <div class="meta"><span class="dot" style="background:${s.color}"></span>${esc(s.name)} · <span class="${late ? "late" : ""}">${fmt(t.date)}${late ? " (atrasada)" : ""}</span> · <span class="p${t.prio}">● ${["", "Alta", "Média", "Baixa"][t.prio]}</span></div></div>
    <button class="ico" onclick="editTask('${t.id}')">✏️</button><button class="ico" onclick="delTask('${t.id}')">🗑</button></div>`;
}

function render() {
  const { tasks: T, videos: V, subjects: SB } = S;
  const pend = T.filter(t => !t.done), late = pend.filter(t => t.date && t.date < today()), done = T.length - pend.length;
  const unseen = V.filter(v => !v.seen).length;
  document.documentElement.dataset.theme = S.theme;
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("on", b.dataset.t === S.tab));
  document.querySelectorAll("main section").forEach(s => s.hidden = s.id !== S.tab);

  // Abas inteligentes: contadores que mudam de cor quando há atrasos
  $("#b-tarefas").textContent = pend.length || "";
  $("#b-tarefas").classList.toggle("red", late.length > 0);
  $("#b-materias").textContent = SB.length || "";
  $("#b-videos").textContent = unseen || "";

  // Painel
  const next = [...pend].sort(cmp)[0];
  $("#painel").innerHTML = `
    <div class="stats">${[["✅ Concluídas", done + "/" + T.length], ["⏳ Pendentes", pend.length], ["🔥 Atrasadas", late.length], ["🎬 Aulas vistas", (V.length - unseen) + "/" + V.length]]
      .map(x => `<div class="stat"><small>${x[0]}</small><b>${x[1]}</b></div>`).join("")}</div>
    <div class="card"><h3>Progresso geral · ${pct(done, T.length)}%</h3><div class="bar"><i style="width:${pct(done, T.length)}%"></i></div></div>
    ${next ? `<div class="card hint">💡 <b>Sugestão:</b> comece por <b>${esc(next.name)}</b> (${esc(sub(next.subject).name)}) — ${fmt(next.date)}</div>` : `<div class="card hint">🎉 Tudo em dia! Adicione novas tarefas.</div>`}
    <div class="card"><h3>Por matéria</h3>${SB.map(s => { const ts = T.filter(t => t.subject === s.id), d = ts.filter(t => t.done).length;
      return `<div class="sub"><div class="top"><span><span class="dot" style="background:${s.color}"></span>${esc(s.name)}</span><small>${d}/${ts.length}</small></div><div class="bar"><i style="width:${pct(d, ts.length)}%;background:${s.color}"></i></div></div>`; }).join("") || '<div class="empty">Sem matérias.</div>'}</div>`;

  // Tarefas (busca + filtro)
  const list = T.filter(t => (S.filter === "all" || (S.filter === "pending" ? !t.done : t.subject === S.filter)) && t.name.toLowerCase().includes(S.q.toLowerCase()))
    .sort((a, b) => (a.done - b.done) || cmp(a, b));
  $("#tarefas").innerHTML = `<div class="row" style="margin-bottom:14px">
    <input class="grow" id="q" placeholder="🔎 Buscar tarefa..." value="${esc(S.q)}" oninput="S.q=this.value;render();document.getElementById('q').focus()">
    <select onchange="set('filter',this.value)"><option value="all">Todas</option><option value="pending" ${S.filter === "pending" ? "selected" : ""}>Pendentes</option>
    ${SB.map(s => `<option value="${s.id}" ${S.filter === s.id ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select>
    <button class="btn" onclick="editTask()">+ Nova tarefa</button></div>
    <div class="card">${list.map(taskRow).join("") || '<div class="empty">Nenhuma tarefa encontrada.</div>'}</div>`;

  // Matérias
  $("#materias").innerHTML = `<div class="row" style="margin-bottom:14px"><button class="btn" onclick="editSubj()">+ Nova matéria</button></div>
    <div class="grid">${SB.map(s => `<div class="card" style="border-top:4px solid ${s.color}"><h3>${esc(s.name)}</h3>
      <p class="mu">${T.filter(t => t.subject === s.id).length} tarefas · ${V.filter(v => v.subject === s.id).length} aulas</p>
      <button class="ghost" onclick="editSubj('${s.id}')">✏️ Editar</button> <button class="ghost" onclick="delSubj('${s.id}')">🗑 Remover</button></div>`).join("")}</div>`;

  // Videoaulas
  $("#videos").innerHTML = `<div class="row" style="margin-bottom:14px"><button class="btn" onclick="editVid()">+ Nova videoaula</button></div>
    <div class="grid">${V.map(v => `<div class="card vid"><iframe loading="lazy" src="https://www.youtube-nocookie.com/embed/${ytId(v.url)}" allowfullscreen></iframe>
      <h3 style="margin-top:10px">${esc(v.name)}</h3><div class="meta"><span class="dot" style="background:${sub(v.subject).color}"></span>${esc(sub(v.subject).name)}</div>
      <div class="row" style="margin-top:8px"><label><input type="checkbox" ${v.seen ? "checked" : ""} onchange="togVid('${v.id}')"> Assistida</label>
      <button class="ico" onclick="editVid('${v.id}')">✏️</button><button class="ico" onclick="delVid('${v.id}')">🗑</button></div></div>`).join("") || '<div class="empty card">Nenhuma videoaula. Cole um link do YouTube!</div>'}</div>`;

  $("#sess").textContent = S.sessions;
}

/* ---------- Foco (Pomodoro) ---------- */
let left = 1500, mode = "Foco", iv = null;
function tick() {
  $("#time").textContent = String(left / 60 | 0).padStart(2, "0") + ":" + String(left % 60).padStart(2, "0");
  $("#mode").textContent = mode === "Foco" ? "🎯 Foco" : "☕ Pausa";
}
$("#start").onclick = () => {
  if (iv) { clearInterval(iv); iv = null; $("#start").textContent = "Continuar"; return; }
  $("#start").textContent = "Pausar";
  iv = setInterval(() => {
    if (--left <= 0) {
      if (mode === "Foco") { S.sessions++; save(); $("#sess").textContent = S.sessions; mode = "Pausa"; left = 300; }
      else { mode = "Foco"; left = 1500; }
    }
    tick();
  }, 1000);
};
$("#reset").onclick = () => { clearInterval(iv); iv = null; mode = "Foco"; left = 1500; $("#start").textContent = "Iniciar"; tick(); };

/* ---------- Geral ---------- */
$("#tabs").onclick = e => { const b = e.target.closest(".tab"); if (b) setTab(b.dataset.t); };
$("#theme").onclick = () => { S.theme = S.theme === "dark" ? "light" : "dark"; save(); render(); };
document.addEventListener("keydown", e => {   // atalhos: teclas 1 a 5 trocam de aba
  if (/INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
  const t = ["painel", "tarefas", "materias", "videos", "foco"][e.key - 1]; if (t) setTab(t);
});
$("#exp").onclick = () => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(S)], { type: "application/json" }));
  a.download = "studyhub-backup.json"; a.click();
};
$("#imp").onchange = e => {
  const r = new FileReader();
  r.onload = () => { try { Object.assign(S, JSON.parse(r.result)); save(); render(); } catch (x) { alert("Arquivo inválido."); } };
  r.readAsText(e.target.files[0]);
};

render(); tick();
